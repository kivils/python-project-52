### Hexlet tests and linter status:
[![Actions Status](https://github.com/Xrustic/python-project-52/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xrustic/python-project-52/actions)