### Hexlet tests and linter status:
[![Actions Status](https://github.com/Xrustic/python-project-52/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xrustic/python-project-52/actions)

Приложение: http://127.0.0.1:8000/